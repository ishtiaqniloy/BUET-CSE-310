int main(){
    int a,b,i;
    
    //a=0;
    
    for(a=0; a<=5; a++){
    	println(a);
    	b=3;
    	while(b>0){
    		println(b);
    		b--;
    	}

    }

}
