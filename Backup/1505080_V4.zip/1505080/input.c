int x,y,z; float a;

int foo(int a, int b){

	println(a);
	println(b);
	println(a%b);

	return (a+b);

	println(-1);

}

int f(){
	z = z + 5;

	println(z);

	return z;
}

int main(){
	int a[2],c,i,j ; float d;

	a[0] = 9;
	a[1] = 4;

	i = foo(a[0], a[1]);

	println(i);

	a[1] = 4;
	
	println(a[1]++);
	println(a[1]++);

	
	println(a[1]--);

	foo(a[1]++, a[1]++);


	//return 0;
}