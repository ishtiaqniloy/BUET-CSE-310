int x,y,z; float a;

int foo(int a, int b){

	println(a);
	println(b);
	println(a%b);

	return (a+b);

	println(-1);

}

int f(){
	z = z + 5;

	println(z);

	return z;
}

int main(){
	int a[2],c,i,j ; float d;
	
	f();
	f();

	c = 5;
	d = 2;

	i=foo(c,d);

	println(i);

	println(55);

	println(f());


	return 0;
}