int x,y,z; float a;

int f(){
	x = 0;

	if(x>=0){
		x=1;
	}

}

int main(){
	int a[2],c,i,j ; float d;
	
	c = 2/4;

	i = 3%2;

	c++;
	a[0]++;
	d--;
	a[1]--;

	a[0]=1;
	a[1]=5;
	i= a[0]+a[1];
	j= 2*3+(5%3 < 4 && 8) || 2 ;
	d=var(1,2*3)+3.5*2;

	println(i);

	return 0;
}