int x,y,z; float a;

int f(){
	x = 0;

	if(x>=0){
		x=1;
	}

}

int main(){
	int a[2],c,i,j ; float d;

	i=2;

	println(i);

	return 0;
}